#include <cmath>
#include <algorithm>
#include <iostream>
#include <stdlib.h>

using namespace std;

class Polynomial;

class Term {
    friend Polynomial;
    friend ostream& operator <<(ostream&, const Polynomial&);
protected:
    int coef;
    int exp;
};

class Polynomial {
public:
    Polynomial();

    Polynomial Add(Polynomial b);
    Polynomial Subtract(Polynomial b);
    Polynomial Multiply(Polynomial b);

    int Eval(int f);

    void NewTerm(const int coef, const int exp);
    int Display();
    int GetData(int);
    friend ostream& operator <<(ostream&, const Polynomial&);
    void AddTerm(int coef, int exp);
private:
    static Term* termArray;
    static int capacity;
    static int free; 

    int start, finish;
    int terms;
    Polynomial TermMultiply(int coef, int exp); 
};
void Polynomial::AddTerm(int coef, int exp) {
    int indx = finish;
    int indx2 = indx;
    while (indx2 >= start) {
		//exp가 같은 경우 처리
		for(int aPos=start;aPos<=finish;aPos++){
			if(termArray[aPos].exp == exp){
				termArray[aPos].coef += coef;
				if(termArray[aPos].coef == 0){
					//shift left [i]=[i+1]
					for(int i=aPos;i<indx2;i++){
						termArray[i] = termArray[i+1];
					}
					finish--;
					free--;
					terms--;
					indx2 = finish;
				}
				return;
			}
		}
    }
    while (indx >= start) {
		//exp가 같은 것이 없는 경우
		int import_pos = start;
		while((import_pos<=indx)&&(termArray[import_pos].exp > exp)){
			import_pos++;
		}
		//shift right //요소 추가 [i]=[i-1]
		for(int i=indx+1;i>0;i--){
			termArray[i] = termArray[i-1];
		}
		finish++;
		free++;
		terms++;
		indx = finish;
		termArray[import_pos].coef = coef;
		termArray[import_pos].exp = exp;
		return;
    }

    return;
}

ostream& operator <<(ostream& stream, const Polynomial& p) {
    int aPos = p.start;
    //구현
	if(aPos == -1){
		stream << "0\n";
		return stream;
	}
	for(;aPos<=p.finish;aPos++){
		stream << Polynomial::termArray[aPos].coef << "x^" << Polynomial::termArray[aPos].exp;
				
		if((aPos-p.finish)!=0){
			stream << " + ";
		}
	}
    stream << "\n";
    return stream;
}

Polynomial::Polynomial()
{
    start = -1;
    finish = -1;
    terms = 0;
}

void Polynomial::NewTerm(const int c, const int e)
{
    if (c == 0) return;
    if (free == capacity)
    {
        capacity *= 2;
        Term* temp = new Term[capacity];
        copy(termArray, termArray + free, temp);
        delete[] termArray;
        termArray = temp;
    }
		//구현
		termArray[free].coef = c;
		termArray[free].exp = e;
		free++;
}

int Polynomial::GetData(int numTerms) {
    /*
    coef = rand() % numTerms;//coef가 0이면 난수를 다시 생성
    newExpo = rand() % numTerms*2;//지수는 내림차순으로 난수 생성
		
    */
    int degree = 2 * numTerms;
    start = free;
    int expo = degree;
    int i;
    int coef;
    int newExpo;

    for (i = degree; i > 0; i--) {
		//구현
		do{
			coef = rand() % numTerms;
		}while(coef==0);
		do{
			newExpo = rand() % degree;
		}while(newExpo>=expo);
		expo=newExpo;
		NewTerm(coef,expo);
		if(expo==0){
			break;
		}
    }
		//구현
	finish = free-1;
	terms = finish - start +1;
	
    return 0;
  
}

Polynomial Polynomial::Add(Polynomial b)
{
    Polynomial c;
    int aPos = start, bPos = b.start;
    if ((aPos == -1) && (bPos == -1)) return c;

    c.start = free;
    while ((aPos != -1 && aPos <= finish) && (bPos != -1 && bPos <= b.finish)) {
	      if(termArray[aPos].exp == b.termArray[bPos].exp){
			  int t = termArray[aPos].coef + b.termArray[bPos].coef;
			  if(t!=0){
				  c.NewTerm(t,termArray[aPos].exp);
			  }
			  aPos++;
			  bPos++;
		  }else if(termArray[aPos].exp > b.termArray[bPos].exp){
			  c.NewTerm(termArray[aPos].coef,termArray[aPos].exp);
			  aPos++;
		  }else{
			  c.NewTerm(b.termArray[bPos].coef,b.termArray[bPos].exp);
			  bPos++;
		  }
    }
    for (; aPos != -1 && aPos <= finish; aPos++){
		c.NewTerm(termArray[aPos].coef,termArray[aPos].exp);
	}
       //구현
    for (; bPos != -1 && bPos <= b.finish; bPos++){
		c.NewTerm(b.termArray[bPos].coef,b.termArray[bPos].exp);
	}
        //구현
		//구현
	c.finish = free -1;
	c.terms = c.finish - c.start + 1;
    return c;
}

Polynomial Polynomial::Subtract(Polynomial b)
{
    Polynomial c;
    int aPos = start, bPos = b.start;
    if ((aPos == -1) && (bPos == -1)) return c;

    c.start = free;
    while ((aPos != -1 && aPos <= finish) && (bPos != -1 && bPos <= b.finish)){
      //구현
		if(termArray[aPos].exp == b.termArray[bPos].exp){
			  int t = termArray[aPos].coef - b.termArray[bPos].coef;
			  if(t!=0){
				  c.NewTerm(t,termArray[aPos].exp);
			  }
			  aPos++;
			  bPos++;
		  }else if(termArray[aPos].exp > b.termArray[bPos].exp){
			  c.NewTerm(termArray[aPos].coef,termArray[aPos].exp);
			  aPos++;
		  }else{
			  c.NewTerm(-b.termArray[bPos].coef,b.termArray[bPos].exp);
			  bPos++;
		  }
        }
    for(; aPos != -1 && aPos <= finish; aPos++){
		c.NewTerm(termArray[aPos].coef,termArray[aPos].exp);
	}
       //구현
    for(; bPos != -1 && bPos <= b.finish; bPos++){
		c.NewTerm(-b.termArray[bPos].coef,b.termArray[bPos].exp);
	}
       //구현

		//구현
	c.finish = free -1;
	c.terms = c.finish - c.start + 1;
    return c;
}

Polynomial Polynomial::TermMultiply(int ccoef, int eexp) {
    Polynomial c;
    if (start == -1) return c;

    c.start = free;
    int aPos = start;
    while (aPos <= finish) {
        //구현
		/*
			if(termArray[aPos].exp == eexp){
				//같으면... 더해주고 없으면 걍 붙이면 되거든?
				int t = termArray[aPos].coef + ccoef;
				if(t!=0){
					c.NewTerm(t,termArray[aPos].exp);
				}
				aPos++;
			}
			else if(termArray[aPos].exp > eexp){
				aPos++;
				continue;
			}
			else{
				c.NewTerm(ccoef,eexp);
			}
			*/
			for(;aPos<=finish;aPos++){
				int multcoef = termArray[aPos].coef * ccoef;
				int multexp = termArray[aPos].exp + eexp;
				c.NewTerm(multcoef,multexp);
			}
    }
		//구현
	c.finish = free -1;
	c.terms = c.finish - c.start +1;
    return c;
}

Polynomial Polynomial::Multiply(Polynomial b)
{
    Polynomial result; 
    int bPos = b.start;
    if (start == -1 || bPos == -1) return result;
    while (bPos <= b.finish) {
	     //구현
       //this->TermMultiply(bc, be);를 사용
				//구현
		for(int bPos=b.start;bPos<=b.finish;bPos++){
			result.Add(this->TermMultiply(b.termArray[bPos].coef,b.termArray[bPos].exp));
		}
    }
    return result;
}

int Polynomial::Eval(int x) {
    /*
    x의 3제곱은 pow(x,3)
    */
    if (start == -1) return 0;
    int sum = 0;
    for (int i = start; i <= finish; ++i) {
		//구현
		sum += termArray[i].coef * pow(x,termArray[i].exp);
    }
    return sum;
}

//static 변수 초기화 구현
int Polynomial::capacity = 100;
int Polynomial::free = 0; 
Term* Polynomial::termArray = new Term[100];

// ---- 메뉴 관련 ----
enum Menu { INPUT = 1, ADD, SUBTRACT, MULTIPLY, EVAL, ADDTERM, EXIT };

static void printMenu() {
    cout << "1.INPUT\n";
    cout << "2.ADD\n";
    cout << "3.SUBTRACT\n";
    cout << "4.MULTIPLY\n";
    cout << "5.EVAL\n";
    cout << "6.ADDTERM\n";
    cout << "7.EXIT\n";
    cout << "선택> ";
}

int main() {
    srand(49);
    int choice;
    Polynomial P1, P2, P3, P4, P5;

    while (true) {
        printMenu();
        if (!(cin >> choice)) break;
        switch (static_cast<Menu>(choice)) {
        case INPUT:
            P1.GetData(5);
            P2.GetData(9);
            cout << P1;
            cout << P2;
            break;
        case ADD:
            P3 = P1.Add(P2);
            cout << P3;
            break;
        case SUBTRACT:
            P4 = P1.Subtract(P2);
            cout << P4;
            break;
        case MULTIPLY:
            P5 = P1.Multiply(P2);
            cout << P5;
            break;
        case EVAL: {
                 int result = P5.Eval(3);
                 cout << result << "\n";
                 break;
        }
        case ADDTERM:
            P1.AddTerm(9, 9);
            cout << P1;
            break;
        case EXIT:
            cout << "프로그램을 종료합니다.\n";
            return 0;
        default:
            cout << "잘못된 선택입니다.\n";
            break;
        }
    }

    cout << "프로그램을 종료합니다.\n";
    return 0;
}
